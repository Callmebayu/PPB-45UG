package com.example.aplikasientrydata;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    protected Cursor cursor;
    Database database;
    Button btnsimpan;
    TextView nama, tanggal, Desa, Jutsu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        database = new Database(this);
        nama = findViewById(R.id.nama);
        tanggal = findViewById(R.id.tanggal);
        Desa = findViewById(R.id.Desa);
        Jutsu = findViewById(R.id.Jutsu);
        btnsimpan = findViewById(R.id.btnsimpan);

        SQLiteDatabase db = database.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM naruto WHERE nama = '" +
                getIntent().getStringExtra("nama")+"'", null);
        cursor.moveToFirst();
        if (cursor.getCount() >0) {
            cursor.moveToPosition(0);
            nama.setText(cursor.getString(0).toString());
            tanggal.setText(cursor.getString(1).toString());
            Desa.setText(cursor.getString(2).toString());
            Jutsu.setText(cursor.getString(3).toString());
        }
    }
}